<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-bold text-3xl text-center text-white leading-tight  bg-indigo-900 border-indigo-300 ">
            <?php echo e(__('ANNOUNCEMENT')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
        <div class="p-6 bg-white border-b border-gray-200">
            <section class="justify-center">
                <div class="container mx-auto">
                    <div class="flex flex-wrap px-6">
                        <div class="w-full md:px-4 lg:px-6 py-5">

                            <?php
                                $id = $detailAnnouncement->id;
                            ?>
                            <div class="">
                                <?php if($detailAnnouncement->picture != null): ?>
                                    <img src="<?php echo e(url($detailAnnouncement->picture)); ?>"
                                        class="h-auto w-full border-white border-8">
                                <?php endif; ?>
                            </div>
                            <div class="px-4 py-4 md:px-10">
                                <div class="flex flex-row">
                                    <div class="pt-1">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none"
                                            viewBox="0 0 24 24" stroke="#dee2e6">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                        </svg>
                                    </div>
                                    <div>
                                        <p class="p-1 text-gray-300 font-bold">
                                            <?php echo e($detailAnnouncement->created_at->format('d/m/Y')); ?></p>
                                    </div>
                                </div>
                                <h1 class="font-bold text-xl md:text-3xl">
                                    <?php echo e($detailAnnouncement->title); ?>

                                </h1>
                                <textarea class="resize-none border-none w-full h-40 pt-2 py-2 text-base md:text-xl" disabled><?php echo e($detailAnnouncement->description); ?></textarea>
                
                                
                            </div>
                        </div>
                    </div>
            </section>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sms\resources\views/manage_announcement/detail_announcement_parent.blade.php ENDPATH**/ ?>