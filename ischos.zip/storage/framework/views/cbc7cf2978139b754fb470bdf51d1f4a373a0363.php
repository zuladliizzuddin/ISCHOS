<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="uppercase font-bold text-3xl text-center text-white leading-tight  bg-indigo-900 border-indigo-300 ">
            <?php echo e(__('Add Social Media Group')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="p-6 bg-white border-b border-gray-200">
                <section class="justify-center">
                    <div class="container mx-auto">
                        <div class="flex flex-wrap px-6">
                            <div class="w-full md:px-4 lg:px-6 py-5">

                                <?php $__currentLoopData = $viewSocialMediaGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $id = $item->id;
                                    ?>

                                    <form method="POST"
                                        action="<?php echo e(route('socialMediaGroup.updateSocialMediaGroup')); ?>/<?php echo e($id != null ? $id : 0); ?>"
                                        enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="grid grid-cols-1 mt-5 mx-7">
                                            <select name="platform"
                                                class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent">
                                                <option>Choose the platform</option>
                                                <option value="whatsapp"
                                                    <?php echo e(old('platform', $item->platform) == 'whatsapp' ? 'selected' : ''); ?>>
                                                    Whatsapp</option>
                                                <option value="telegram"
                                                    <?php echo e(old('platform', $item->platform) == 'telegram' ? 'selected' : ''); ?>>
                                                    Telegram</option>
                                            </select>

                                        </div>

                                        <div class="grid grid-cols-1 mt-5 mx-7">
                                            <label
                                                class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Link
                                                Media Social</label>
                                            <input name="link"
                                                class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                                                type="text" value="<?php echo e($item->link); ?>" placeholder="Insert Link" />
                                        </div>

                                        <div class="grid grid-cols-1 mt-5 mx-7">
                                            <label
                                                class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Name
                                                of Media Social</label>
                                            <textarea name="name"
                                                class="resize-none py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                                                type="text"
                                                placeholder="Insert Name of Media Social"><?php echo e($item->name); ?></textarea>
                                        </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>

                    </div>
                </section>

                <div class='flex items-center justify-center pt-10 pb-8 '>
                    <button type="submit"
                        class=' md:w-5/12 w-11/12 bg-indigo-900 border-indigo-300 rounded-full shadow-xl font-medium text-white px-4 py-2'>SAVE</button>
                </div>
                </form>

            </div>
        </div>



 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sms\resources\views/manage_social_media_group/edit_media_teacher.blade.php ENDPATH**/ ?>