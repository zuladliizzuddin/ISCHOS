<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-bold text-3xl text-center text-white leading-tight  bg-indigo-900 border-indigo-300 ">
            <?php echo e(__('TIMETABLE')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
        <div class="p-6 bg-white border-b border-gray-200">
            <section class="justify-center">
                <div class="container mx-auto">
                    <div class="flex flex-wrap px-6">
                        <div class="w-full md:px-4 lg:px-6 py-5">
                            <div class="px-4 py-4 md:px-10">
                                <h1 class="font-bold text-3xl text-lg text-center ">
                                    <?php if($detailSchedule != null): ?>
                                        <?php echo e($detailSchedule->school_class->class_name); ?>

                                    <?php endif; ?>
                                </h1>
                            </div>

                            <div class="">
                                <?php if($detailSchedule != null): ?>
                                    <img src="<?php echo e(url($detailSchedule->image)); ?>"
                                        class="h-auto w-full border-white border-8">
                                <?php else: ?>
                                    <h1 class="font-bold text-3xl text-lg text-center text-red-500 ">No Schedule Yet
                                    </h1>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sms\resources\views/manage_class_schedule/view_schedule_parent.blade.php ENDPATH**/ ?>