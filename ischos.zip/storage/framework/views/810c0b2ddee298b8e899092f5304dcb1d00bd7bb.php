<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-bold text-3xl text-center text-white leading-tight  bg-indigo-900 border-indigo-300 uppercase">
            <?php echo e(__('Profile')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="p-6 bg-white border-b border-gray-200">
                <section class="justify-center">
                    <div class="container mx-auto">
                        <div class="flex flex-wrap px-6">
                            <div class="w-full md:px-4 lg:px-6 py-5">
                                <?php if($errors->edit->any()): ?>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','errors' => $errors->edit]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->edit)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                <?php endif; ?>

                                <form method="post" action="<?php echo e(route('manage_profile.update_profile')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="grid grid-cols-1 mt-5 mx-7">
                                        <label
                                            class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">First
                                            Name</label>
                                        <input
                                            class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                                            type="text" name="first_name" value="<?php echo e($parentData->first_name); ?>" />
                                    </div>

                                    <div class="grid grid-cols-1 mt-5 mx-7">
                                        <label
                                            class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Last
                                            Name</label>
                                        <input
                                            class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                                            type="text" name="last_name" value="<?php echo e($parentData->last_name); ?>" />
                                    </div>

                                    <div class="grid grid-cols-1 mt-5 mx-7">
                                        <label
                                            class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Phone
                                            Number</label>
                                        <input
                                            class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                                            type="text" name="phone_number" value="<?php echo e($parentData->phone_number); ?>" />
                                    </div>

                                    <div class="grid grid-cols-1 mt-5 mx-7">
                                        <label
                                            class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Email</label>
                                        <input
                                            class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                                            type="text" name="email" value="<?php echo e($parentData->email); ?>" />
                                    </div>

                                    <div class="grid grid-cols-1 mt-5 mx-7">
                                        <label
                                            class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Username</label>
                                        <input
                                            class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                                            type="text" name="username" value="<?php echo e($parentData->username); ?>" />
                                    </div>

                                    <div class='flex items-center justify-center pt-5 pb-8 '>
                                        <button type="submit"
                                            class='md:w-5/12 w-11/12 bg-indigo-900 border-indigo-300 rounded-full shadow-xl font-medium text-white px-4 py-2'>UPDATE</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sms\resources\views/manage_profile/edit_profile_parent.blade.php ENDPATH**/ ?>