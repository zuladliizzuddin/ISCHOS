<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
            <h2 class="font-bold text-3xl text-center text-white leading-tight  bg-indigo-900 border-indigo-300 ">
                <?php echo e(__('ANNOUNCEMENT')); ?>

            </h2>
     <?php $__env->endSlot(); ?>

    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
        <div class="p-6 bg-white border-b border-gray-200">
            <div class="min-h-screen py-6 flex flex-col ">
                <div class="grid lg:grid-cols-2 md:grid-cols-2 sm:grid-cols-2 grid-cols-2 gap-4 px-4 ">
                    <!-- SMALL CARD ROUNDED -->
                    <div class="py-12"> </div>
                    <div class="py-12"> </div>
                    <a href="<?php echo e(route('announcement.listBanner')); ?>">
                        <div class="hover:transition-all">
                            <div
                                class="grid bg-white shadow-lg dark:bg-gray-800 bg-opacity-95 border-opacity-60 | p-4 border-solid rounded-3xl border-2 | justify-around cursor-pointer | hover:bg-grey dark:hover:bg-indigo-600 hover:border-transparent | transition-colors duration-500 | ">
                                <div class="flex justify-center items-center">
                                    <img class="origin-center rotate-45 w-auto h-16"
                                        src="https://cdn-icons-png.flaticon.com/512/6502/6502196.png" alt="" />
                                </div>
                                <div class="text-center pt-2">
                                    <p class="text-gray-900 dark:text-gray-300 font-semibold">Banner</p>
                                </div>
                            </div>
                        </div>
                    </a>
                    <!-- SMALL CARD ROUNDED -->
                    <a href="<?php echo e(route('announcement.listAnnouncement')); ?>">
                        <div
                            class="grid bg-white shadow-lg dark:bg-gray-800 bg-opacity-95 border-opacity-60 | p-4 border-solid rounded-3xl border-2 | justify-around cursor-pointer | hover:bg-grey dark:hover:bg-indigo-600 hover:border-transparent | transition-colors duration-500">
                            <div class="flex justify-center items-center">
                                <img class="w-auto h-16"
                                    src="https://cdn-icons-png.flaticon.com/512/1378/1378644.png" alt="" />
                            </div>
                            <div class="text-center pt-2">
                                <p class="text-gray-900 dark:text-gray-300 font-semibold">Announcement</p>
                            </div>
                        </div>
                    </a>

                </div>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sms\resources\views/manage_announcement/option_add_announcement_teacher.blade.php ENDPATH**/ ?>