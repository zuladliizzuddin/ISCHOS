<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-bold text-3xl text-center text-white leading-tight  bg-indigo-900 border-indigo-300 uppercase">
            <?php echo e(__('Financial Information')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="p-6 bg-white border-b border-gray-200">
                <div class="min-h-screen dark:bg-gray-900 py-6 flex flex-col sm:py-12">
                    <div class="flex flex-col p-4">
                        <?php
                            $id = $detailPayment->id;
                        ?>

                        <form method="POST" action="<?php echo e('/payment/paymentGateway'); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="grid grid-cols-1 mt-5 mx-7">
                                <label
                                    class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Payment
                                    Title</label>
                                <input name="payment_title"
                                    class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                                    type="text" value="<?php echo e($detailPayment->payment_title); ?>" disabled />
                                <input name="id" type="hidden" value="<?php echo e($detailPayment->id); ?>" />
                            </div>

                            <div class="grid grid-cols-1 mt-5 mx-7">
                                <label
                                    class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Description</label>
                                <input name="description"
                                    class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                                    type="text" value="<?php echo e($detailPayment->description); ?>" disabled />
                            </div>

                            <div class="grid grid-cols-1 mt-5 mx-7">
                                <label
                                    class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Amount(RM)</label>
                                <input name="amount"
                                    class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                                    type="text" value="<?php echo e($detailPayment->amount); ?>" disabled />
                            </div>

                            <?php if($paymentStatus->status == 'Paid'): ?>
                                <div class="grid grid-cols-1 mt-5 mx-7">
                                    <label
                                        class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold ">Status</label>
                                    <input type="status"
                                        class=' py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent text-green-600 font-extrabold bg-green-100'
                                        type="text" value="<?php echo e($paymentStatus->status); ?>" disabled />
                                </div>
                            <?php else: ?>
                                <div class="grid grid-cols-1 mt-5 mx-7">
                                    <label
                                        class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold ">Status</label>
                                    <input name="status"
                                        class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent text-red-600 font-extrabold bg-red-100"
                                        type="text" value="<?php echo e($paymentStatus->status); ?>" disabled />
                                </div>
                            <?php endif; ?>


                            <?php if($paymentStatus->status == 'Not Paid'): ?>
                                <div class='flex items-center justify-center pt-10 pb-8 '>
                                    <button type="submit"
                                        class='  md:w-5/12 w-11/12 rounded-full bg-indigo-900 border-indigo-300  shadow-xl font-medium text-white px-4 py-2'>PAY</button>
                                </div>

                            <?php else: ?>
                        </form>
                        <div class='flex items-center justify-center pt-10 pb-8 '>
                            
                            <button onclick="window.location.href='<?php echo e('/payment/viewReceipt'); ?>/<?php echo e($id != null ? $id : 0); ?>'"
                                class=" md:w-5/12 w-11/12 rounded-full bg-indigo-900 border-indigo-300  shadow-xl font-medium text-white px-4 py-2">
                                RECEIPT
                            </button>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sms\resources\views/manage_payment/detail_payment_parent.blade.php ENDPATH**/ ?>