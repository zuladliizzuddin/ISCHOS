<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-3xl text-center text-white leading-tight  bg-indigo-900 border-indigo-300 ">
            <?php echo e(__('Class Information')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">

        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                  <div class="p-6 bg-white border-b border-gray-200">
                    <h2 class="font-bold text-3xl text-center text-black  leading-tight  bg-gray-500 border-indigo-300 ">
                        <?php echo e(__('1 Zamrud')); ?>

                    </h2>
                    <div><br></div>
                    <div class="shadow flex">
                        <input class="w-full p-2 border-0" type="text" placeholder="Search...">
                        <button class="bg-white w-auto flex justify-end items-center text-blue-500 p-2 hover:text-blue-400">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                            </svg>
                        </button>
                    </div>

                    <div class="min-h-screen dark:bg-gray-900 py-6 flex flex-col justify-center sm:py-12">
                        <div class="flex flex-col p-4">
                          <!-- SMALL CARD ROUNDED -->
                          <a href="<?php echo e(('/dashboard/detailStudInfo')); ?>">
                          <div class="bg-white shadow-lg dark:bg-gray-800 bg-opacity-95 border-opacity-60 | p-4 border-solid rounded-3xl border-2 | flex justify-around cursor-pointer | hover:bg-gray-100 dark:hover:bg-gray-900 hover:border-transparent | transition-colors duration-500">
                            <img class="w-auto h-32 border-2 shadow-md" src="<?php echo e(asset('img/azwan.jpg')); ?>" alt="" />
                            <div class="flex flex-col justify-center p-5">
                              <p class="text-gray-900 dark:text-gray-300 font-bold">MOHAMAD AZUAN BIN SIDIK</p>
                              <p class="text-black dark:text-gray-100 text-justify ">Lelaki</p>
                              <p class="text-black dark:text-gray-100 text-justify ">011-23456748</p>
                            </div>
                          </div>
                          </a>
                          <div><br></div>
                          <!-- END SMALL CARD ROUNDED -->
                      
                          <!-- SMALL CARD ROUNDED -->
                          <div class="bg-white shadow-lg dark:bg-gray-800 bg-opacity-95 border-opacity-60 | p-4 border-solid rounded-3xl border-2 | flex justify-around cursor-pointer | hover:bg-gray-100 dark:hover:bg-gray-900 hover:border-transparent | transition-colors duration-500">
                            <img class="w-auto h-32" src="<?php echo e(asset('img/azrul.jpg')); ?>" alt="" />
                            <div class="flex flex-col justify-center p-5">
                              <p class="text-gray-900 dark:text-gray-300 font-bold">MOHAMAD AZUAN BIN SIDEK</p>
                              <p class="text-black dark:text-gray-100 text-justify font-semibold">Lelaki</p>
                              <p class="text-black dark:text-gray-100 text-justify font-semibold">011-23456748</p>
                            </div>
                          </div>
                          <div><br></div>
                          <!-- END SMALL CARD ROUNDED -->
                      
                         <!-- SMALL CARD ROUNDED -->
                         <div class="bg-white shadow-lg dark:bg-gray-800 bg-opacity-95 border-opacity-60 | p-4 border-solid rounded-3xl border-2 | flex justify-around cursor-pointer | hover:bg-gray-100 dark:hover:bg-gray-900 hover:border-transparent | transition-colors duration-500">
                            <img class="w-auto h-32" src="<?php echo e(asset('img/azrul.jpg')); ?>" alt="" />
                            <div class="flex flex-col justify-center p-5">
                              <p class="text-gray-900 dark:text-gray-300 font-bold">MOHAMAD AZUAN BIN SIDEK</p>
                              <p class="text-black dark:text-gray-100 text-justify font-semibold">Lelaki</p>
                              <p class="text-black dark:text-gray-100 text-justify font-semibold">011-23456748</p>
                            </div>
                          </div>
                          <div><br></div>
                          <!-- END SMALL CARD ROUNDED -->
                      
                         <!-- SMALL CARD ROUNDED -->
                         <div class="bg-white shadow-lg dark:bg-gray-800 bg-opacity-95 border-opacity-60 | p-4 border-solid rounded-3xl border-2 | flex justify-around cursor-pointer | hover:bg-gray-100 dark:hover:bg-gray-900 hover:border-transparent | transition-colors duration-500">
                            <img class="w-auto h-32" src="<?php echo e(asset('img/azrul.jpg')); ?>" alt="" />
                            <div class="flex flex-col justify-center p-5">
                              <p class="text-gray-900 dark:text-gray-300 font-bold">MOHAMAD AZUAN BIN SIDEK</p>
                              <p class="text-black dark:text-gray-100 text-justify font-semibold">Lelaki</p>
                              <p class="text-black dark:text-gray-100 text-justify font-semibold">011-23456748</p>
                            </div>
                          </div>
                          <div><br></div>
                          <!-- END SMALL CARD ROUNDED -->
                        </div>
                      </div>

                      
                </div>
            </div>
        </div>
    </div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sms\resources\views/manage_class_info/list_stud_info_teacher.blade.php ENDPATH**/ ?>