<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 

     <?php $__env->endSlot(); ?>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <div class="min-h-screen py-6 flex flex-col ">
                        <div class="row pb-2 justify-self-end">
                            <button id="button_register" data-toggle="modal" data-target="#registerModal"
                                class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded-l">
                                Add User
                            </button>
                            
                            
                        </div>
                        <div class="flex flex-col">
                            <div class="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-7">
                                <div class="py-2 align-middle inline-block min-w-full  sm:px-6 lg:px-8">
                                    <div class="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
                                        <table class="min-w-full  divide-y divide-gray-200">
                                            <thead class="bg-gray-50 ">
                                                <tr>
                                                    <th scope="col"
                                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                        Name
                                                    </th>
                                                    <th scope="col"
                                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                        No Phone
                                                    </th>
                                                    <th scope="col"
                                                        class="px-6 py-3 text-left  text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                        Action
                                                    </th>
                                                </tr>
                                            </thead>
                                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tbody class="bg-white divide-y divide-gray-200">
                                                    <tr>
                                                        <td class="px-6 py-4 whitespace-nowrap">
                                                            <div class="flex items-center">
                                                                <div>
                                                                    <div class="text-sm font-medium text-gray-900">
                                                                        <?php echo e($list_user->first_name); ?>

                                                                        <?php echo e($list_user->last_name); ?>

                                                                    </div>
                                                                    <div class="text-sm text-gray-500">
                                                                        <?php echo e($list_user->username); ?>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td class="px-6 py-4 whitespace-nowrap">
                                                            <div class="text-sm text-gray-900">
                                                                <?php echo e($list_user->phone_number); ?>

                                                            </div>

                                                        </td>
                                                        <td class=" px-6 py-4 whitespace-nowrap text-sm text-gray-500 ">
                                                            <div class="row gap-2">
                                                                <button id="button_edit" data-toggle="modal"
                                                                    data-target="#editModal<?php echo e($list_user->user_id); ?>"
                                                                    class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded-l">
                                                                    Edit
                                                                </button>

                                                                <form
                                                                    action="<?php echo e(route('manage_user.remove_parent', ['id' => $list_user->user_id])); ?>"
                                                                    method="POST">
                                                                    <?php echo csrf_field(); ?>
                                                                    <button type="submit"
                                                                        onclick="return confirm('Are you sure to delete?')"
                                                                        class=" bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded-r">
                                                                        Delete
                                                                    </button>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <?php echo $__env->make('manage_user.edit_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <!-- More people... -->
                                            </tbody>
                                        </table>
                                        <div class="py-3 px-6 pt-4">
                                            <?php echo e($user->links()); ?>

                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php echo $__env->make('manage_user.add_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<script type="text/javascript">
    <?php if($errors->edit->any()): ?>
        document.getElementById("button_edit").click()
        // if (document.getElementById('button_register')){
        // $('#registerModal').modal('show');
        // } else
        // if (document.getElementById('button_edit')){
        // $('#editModal<?php echo e($list_user->user_id); ?>').modal('show');
    
        // }
    <?php elseif($errors->add->any()): ?>
        document.getElementById("button_register").click()
    <?php endif; ?>
</script>
<?php /**PATH C:\xampp\htdocs\sms\resources\views/manage_user/list_user.blade.php ENDPATH**/ ?>