<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="uppercase font-bold text-3xl text-center text-white leading-tight  bg-indigo-900 border-indigo-300 ">
            <?php echo e(__('Student Information')); ?>


        </h2>
     <?php $__env->endSlot(); ?>
    
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="p-6 bg-white border-b border-gray-200">
                <section class="justify-center">
                    <div class="container mx-auto">
                        <div class="flex flex-wrap px-6">
                            <div class="w-full md:px-4 lg:px-6 py-5">
                                <div class="grid grid-cols-1 mt-5 mx-7">
                                    <div class='flex items-center justify-center w-full'>


                                        <?php
                                            $id = $detailStudent->id;
                                        ?>

                                        <?php if($detailStudent->studImage != null): ?>
                                            <div class="flex">
                                                <img class="w-40 h-40 border-2 shadow-md"
                                                    src="<?php echo e(url($detailStudent->studImage)); ?>" />
                                        <?php endif; ?>
                                    </div>


                                </div>
                            </div>

                            <div class="grid grid-cols-1 mt-5 mx-7">
                                <label
                                    class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Student's
                                    Full Name</label>
                                <input
                                    class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                                    type="text" value="<?php echo e($detailStudent->studFullName); ?>" disabled />
                            </div>

                            <div class="grid grid-cols-1 mt-5 mx-7">
                                <label
                                    class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Student
                                    Identity Card</label>
                                <input
                                    class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                                    type="text" value="<?php echo e($detailStudent->studIdCard); ?>" disabled />
                            </div>
                            <div class="grid grid-cols-1 mt-5 mx-7">
                                <label
                                    class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Address</label>
                                <input
                                    class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                                    type="text" value="<?php echo e($detailStudent->address); ?>" disabled />
                            </div>

                            <div class="grid grid-cols-1 mt-5 mx-7">
                                <label class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Class
                                    Name</label>
                                <input
                                    class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                                    type="text" value="<?php echo e($detailStudent->school_class->class_name); ?>" disabled />
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-5 md:gap-8 mt-5 mx-7">
                                <div class="grid grid-cols-1">
                                    <label
                                        class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Gender</label>
                                    <input
                                        class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                                        type="text" value="<?php echo e($detailStudent->gender); ?>" disabled />
                                </div>
                                <div class="grid grid-cols-1">
                                    <label
                                        class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Age</label>
                                    <input
                                        class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                                        type="text" value="<?php echo e($detailStudent->age); ?>" disabled />
                                </div>
                                <div class="grid grid-cols-1">
                                    <label
                                        class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">B.O.D</label>
                                    <input
                                        class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                                        type="text" value="<?php echo e($detailStudent->brthOfDate); ?>" disabled />
                                </div>
                                <div class="grid grid-cols-1">
                                    <label
                                        class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Religion</label>
                                    <input
                                        class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                                        type="text" value="<?php echo e($detailStudent->religon); ?>" disabled />
                                </div>
                            </div>

                            <div class="grid grid-cols-1 mt-5 mx-7">
                                <label
                                    class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Parent's
                                    Full Name</label>
                                <input
                                    class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                                    type="text" value="<?php echo e($detailStudent->parentFullName); ?>" disabled />
                            </div>
                            <div class="grid grid-cols-1 mt-5 mx-7">
                                <label
                                    class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Parent
                                    Identity Card</label>
                                <input
                                    class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                                    type="text" value="<?php echo e($detailStudent->parentIdCard); ?>" disabled />
                            </div>
                            <div class="grid grid-cols-1 mt-5 mx-7">
                                <label
                                    class="uppercase md:text-sm text-xs text-gray-500 text-light font-semibold">Parental
                                    Salary </label>
                                <input
                                    class="py-2 px-3 rounded-lg border-2 border-purple-300 mt-1 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:border-transparent"
                                    type="text" value="<?php echo e($detailStudent->parentSalary); ?>" disabled />
                            </div>

                            <div class='flex items-center justify-center w-100  md:gap-8 gap-4 pt-5 pb-5 '>
                                <button
                                    class='md:w-5/12 w-2/4 bg-indigo-900 border-indigo-300 rounded-full shadow-xl font-medium text-white px-4 py-2'
                                    onclick="location.href='<?php echo e('/classInfo/editClassStudInfo'); ?>/<?php echo e($id != null ? $id : 0); ?>'">EDIT</button>
                                <button
                                    class='md:w-5/12 w-2/4 bg-indigo-900 border-indigo-300 rounded-full shadow-xl font-medium text-white px-4 py-2'
                                    onclick="confirmDelete('<?php echo e('/classInfo/deleteClassStudInfo'); ?>/<?php echo e($id != null ? $id : 0); ?>')">DELETE</button>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>


<script>
    function confirmDelete(url) {
        if (confirm("Are you sure you want to delete this?")) {
            window.location.replace(url);
        } else {
            false;
        }
    }
</script>
<?php /**PATH C:\xampp\htdocs\sms\resources\views/manage_class_info/detail_class_stud_info_teacher.blade.php ENDPATH**/ ?>