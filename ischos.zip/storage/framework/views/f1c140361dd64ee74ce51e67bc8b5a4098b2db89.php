<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 

     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class=" max-w-7xl mx-auto sm:px-6 lg:px-8 ">
            <div class=" overflow-hidden  sm:rounded-lg ">
                <div class="grid grid-cols-1 place-items-center ">
                    <div style="position: absolute; top:50%; left:50%; transform:translate(-50%, -50%);" class='h-full flex flex-col items-center justify-center w-100  md:gap-8 gap-4  pb-5 '>
                        <button type="button"
                            class=' w-auto bg-indigo-900 border-indigo-300 rounded-lg  font-medium text-white px-4 py-2'>School
                            Announcement</button>
                        <button type="button"
                            class=' w-auto bg-indigo-900 border-indigo-300 rounded-lg  font-medium text-white px-4 py-2' onclick="location.href='<?php echo e(('/announcement')); ?>'">Class
                            Announcement</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>


<?php /**PATH C:\xampp\htdocs\sms\resources\views/manage_announcement/option_announcement_teacher.blade.php ENDPATH**/ ?>