<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-3xl text-center text-white leading-tight  bg-indigo-900 border-indigo-300 ">
            <?php echo e(__('CLASS INFORMATION')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
            <div class="bg-white  overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h2 class="font-bold text-3xl text-center text-black shadow-md leading-tight  bg-gray-200 border-indigo-300 ">
                        <?php echo e($class_name[0]->school_class->class_name); ?>

                    </h2>
                    <div class="min-h-full  dark:bg-gray-900 py-6 flex flex-col justify-center sm:py-12">
                        <div class="flex flex-col p-4">

                            
                            <form action="<?php echo e(route('classInfo.search_student')); ?>" method="get">
                                <div class="flex-1 pr-4 pb-5">
                                    <div class="relative md:w-1/3">
                                        <input name="search" type="search"
                                            class="md:w-full w-full pl-10 pr-4 py-2 rounded-lg shadow-md border-gray-200 font-normal"
                                            placeholder="Search...">
                                        <div class="absolute top-0 left-0 inline-flex items-center p-2">
                                            <button type="submit">
                                                <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6 text-gray-400"
                                                    viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"
                                                    fill="none" stroke-linecap="round" stroke-linejoin="round">
                                                    <rect x="0" y="0" width="24" height="24" stroke="none"></rect>
                                                    <circle cx="10" cy="10" r="7" />
                                                    <line x1="21" y1="21" x2="15" y2="15" />
                                                </svg>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            

                            

                            <div class="w-full  mx-auto bg-white shadow-lg rounded-sm border border-gray-200">
                                <div class="p-3">
                                    <div class="overflow-x-auto">
                                        <!-- Table -->
                                        <table class="table-auto w-full">
                                            <thead class="text-xs font-semibold uppercase text-gray-400 bg-gray-50">
                                                <tr>
                                                    <th class="p-2 whitespace-nowrap">
                                                        <div class="font-semibold text-left">Name</div>
                                                    </th>
                                                </tr>
                                            </thead>
                                            <?php $__currentLoopData = $detailStudent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listSudentinfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                                            <?php
                                                $id = $listSudentinfo->id
                                            ?>
                                                <tbody class="text-sm divide-y divide-gray-100">
                                                    <tr class="hover:bg-gray-100 border-b border-gray-200 py-10" style="cursor: pointer" onclick="window.location.href='<?php echo e(('/classInfo/detailClassStudent')); ?>/<?php echo e($id !=null ? $id:0); ?>'">
                                                        <td class="p-2 whitespace-nowrap">
                                                            <div class="flex items-center">
                                                                <div class="w-10 h-10 flex-shrink-0 mr-2 sm:mr-3">

                                                                    <?php if($listSudentinfo->studImage != null): ?>
                                                                        <img class="rounded-full w-11 h-11 "
                                                                            src="<?php echo e(url($listSudentinfo->studImage)); ?>"
                                                                            width="" height="" alt="Alex Shatov">
                                                                    <?php else: ?>
                                                                        <img class="rounded-full w-11 h-11 "
                                                                            src="<?php echo e(url('img/empty_image.png')); ?>"
                                                                            width="" height="" alt="Alex Shatov">
                                                                    <?php endif; ?>

                                                                </div>
                                                                <div class="font-medium text-gray-800">
                                                                    <?php echo e($listSudentinfo->studFullName); ?>

                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center pt-3">
                                <?php echo $detailStudent->links(); ?>

                            </div>
                            

                            <div class='flex items-center justify-center pt-10 pb-8 '>
                                <button
                                    class='md:w-5/12 w-11/12 bg-indigo-900 border-indigo-300 rounded-full shadow-xl font-medium text-white px-4 py-2'
                                    onclick="location.href='<?php echo e(route('classInfo.addClassStudInfo')); ?>'">ADD</button>
                            </div>

                        </div>
                    </div>


                </div>
            </div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sms\resources\views/manage_class_info/list_class_stud_info_teacher.blade.php ENDPATH**/ ?>