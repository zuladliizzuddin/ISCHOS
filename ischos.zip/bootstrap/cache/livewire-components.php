<?php return array (
  'select2-dropdown' => 'App\\Http\\Livewire\\Select2Dropdown',
);